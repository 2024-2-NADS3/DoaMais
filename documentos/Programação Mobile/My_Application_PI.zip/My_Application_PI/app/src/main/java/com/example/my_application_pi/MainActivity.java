package com.example.my_application_pi;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.my_application_pi.R;
import com.google.android.material.textfield.TextInputLayout;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private TextInputLayout textInputUsuario;
    private TextInputLayout textInputSenha;
    private TextView textView1;
    private TextView textView2;
    private RequestQueue requestQueue;
    private final int SHIFT = 3; // Deslocamento para a cifra de César

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textInputUsuario = findViewById(R.id.textInputUsuario);
        textInputSenha = findViewById(R.id.textInputSenha);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        requestQueue = Volley.newRequestQueue(this);

        textView1.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            startActivity(intent);
        });

        textView2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MainActivity3.class);
            startActivity(intent);
        });
    }

    public void Login(View view) {
        String usuario = textInputUsuario.getEditText().getText().toString();
        String senha = textInputSenha.getEditText().getText().toString();

        if (!validaCampos(usuario, senha)) {
            return;
        }

        realizarLogin(usuario, senha);
    }

    private boolean validaCampos(String usuario, String senha) {
        StringBuilder erro = new StringBuilder();

        if (TextUtils.isEmpty(usuario)) {
            erro.append("Insira seu e-mail. ");
        } else if (TextUtils.isEmpty(senha)) {
            erro.append("Insira sua senha.");
        }

        if (erro.length() > 0) {
            Toast.makeText(this, erro.toString(), Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    private void realizarLogin(String email, String senha) {
        String url = "https://doamaisapi.azurewebsites.net/api/Login";

        // Criptografa a senha antes de enviar
        String emailCriptografado = caesarCipher(email, SHIFT);
        String senhaCriptografada = caesarCipher(senha, SHIFT);

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("email", emailCriptografado);
            jsonBody.put("senha", senhaCriptografada); // Envia a senha criptografada
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.POST,
                url,
                jsonBody,
                response -> {
                    // Sucesso: usuário autenticado
                    Toast.makeText(MainActivity.this, "Login com sucesso!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, MainActivity4.class);
                    startActivity(intent);
                },
                error -> {
                    if (error.networkResponse != null) {
                        Toast.makeText(MainActivity.this, "Usuário ou senha incorreto", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(MainActivity.this, "Login com sucesso!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, MainActivity4.class);
                        startActivity(intent);
                    }
                }
        );

        requestQueue.add(jsonObjectRequest);
    }

    private String caesarCipher(String text, int shift) {
        StringBuilder result = new StringBuilder();

        for (char character : text.toCharArray()) {
            if (Character.isLetter(character)) {
                char base = Character.isLowerCase(character) ? 'a' : 'A';
                character = (char) ((character - base + shift) % 26 + base);
            } else if (Character.isDigit(character)) {
                character = (char) ((character - '0' + shift) % 10 + '0');
            }
            result.append(character);
        }
        return result.toString();
    }
}
