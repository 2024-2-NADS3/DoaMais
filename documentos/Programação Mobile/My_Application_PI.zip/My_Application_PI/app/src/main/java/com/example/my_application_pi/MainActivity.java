package com.example.my_application_pi;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {
    private TextInputLayout textInputUsuario;
    private TextInputLayout textInputSenha;
    private TextView textViewErro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        textInputUsuario = findViewById(R.id.textInputUsuario);
        textInputSenha = findViewById(R.id.textInputSenha);
    }

    public void Login(View view) {

        String usuario = textInputUsuario.getEditText().getText().toString();
        String senha = textInputSenha.getEditText().getText().toString();


        if (!validaCampos(usuario, senha)) {
            return;
        }


        if (usuario.equals("admin") && senha.equals("admin")) {
            Toast.makeText(this, "Login com sucesso!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, MainActivity2.class);
            startActivity(intent);
        } else {

            Toast.makeText(this, "Usuário ou senha incorretos.", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validaCampos(String usuario, String senha) {
        StringBuilder erro = new StringBuilder();


        if (TextUtils.isEmpty(usuario)) {
            erro.append("Insira seu e-mail. ");
        }


        else if (TextUtils.isEmpty(senha)) {
            erro.append("Insira sua senha.");
        }


        if (erro.length() > 0) {
            Toast.makeText(this, erro.toString(), Toast.LENGTH_SHORT).show();
            return false;
        } else {

            return true;
        }
    }
}

