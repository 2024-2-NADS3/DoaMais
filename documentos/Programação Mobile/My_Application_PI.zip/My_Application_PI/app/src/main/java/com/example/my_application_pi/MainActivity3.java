package com.example.my_application_pi;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity3 extends AppCompatActivity {

    private TextInputLayout textInputTipessoa;
    private TextInputLayout textInputNome;
    private TextInputLayout textInputTelefone;
    private TextInputLayout textInputEmail;
    private TextInputLayout textInputSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        textInputTipessoa = findViewById(R.id.textInputTipessoa3);
        textInputNome = findViewById(R.id.textInputNome3);
        textInputTelefone = findViewById(R.id.textInputTelefone3);
        textInputEmail = findViewById(R.id.textInputEmail3);
        textInputSenha = findViewById(R.id.textInputSenha3);
    }

    public void criarConta(View view) {
        String tipoPessoa = textInputTipessoa.getEditText().getText().toString();
        String nome = textInputNome.getEditText().getText().toString();
        String telefone = textInputTelefone.getEditText().getText().toString();
        String email = textInputEmail.getEditText().getText().toString();
        String senha = textInputSenha.getEditText().getText().toString();

        if (!validaCampos(tipoPessoa, nome, telefone, email, senha)) {
            return;
        }

        // Sucesso ao validar
        Toast.makeText(this, "Conta criada com sucesso!", Toast.LENGTH_SHORT).show();
    }

    private boolean validaCampos(String tipoPessoa, String nome, String telefone, String email, String senha) {
        boolean valido = true;

        // Validação do tipo de pessoa (CPF ou CNPJ)
        if (TextUtils.isEmpty(tipoPessoa) || (!tipoPessoa.equalsIgnoreCase("CPF") && !tipoPessoa.equalsIgnoreCase("CNPJ"))) {
            textInputTipessoa.setError("Escolha CPF ou CNPJ");
            valido = false;
        } else {
            textInputTipessoa.setError(null);
        }

        // Validação do nome
        if (TextUtils.isEmpty(nome)) {
            textInputNome.setError("Insira seu nome completo");
            valido = false;
        } else {
            textInputNome.setError(null);
        }

        // Validação do telefone (9 ou 11 dígitos)
        if (TextUtils.isEmpty(telefone) || telefone.length() < 9 || telefone.length() > 11 || !TextUtils.isDigitsOnly(telefone)) {
            textInputTelefone.setError("Insira um número de telefone válido (9 ou 11 dígitos)");
            valido = false;
        } else {
            textInputTelefone.setError(null);
        }

        // Validação do e-mail
        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            textInputEmail.setError("Insira um e-mail válido");
            valido = false;
        } else {
            textInputEmail.setError(null);
        }

        // Validação da senha (8 a 20 caracteres, letras e números, sem espaços ou emojis)
        if (TextUtils.isEmpty(senha) || senha.length() < 8 || senha.length() > 20 || senha.contains(" ") || !senha.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]+$")) {
            textInputSenha.setError("A senha deve ter entre 8 e 20 caracteres, letras e números, sem espaços ou emojis");
            valido = false;
        } else {
            textInputSenha.setError(null);
        }

        return valido;
    }
}
