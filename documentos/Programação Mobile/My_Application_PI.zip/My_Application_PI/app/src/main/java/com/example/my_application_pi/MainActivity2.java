package com.example.my_application_pi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity2 extends AppCompatActivity {

    private TextInputEditText textEditEmail2;
    private TextInputEditText textIEditNovaSenha2;
    private Button button;
    private RequestQueue requestQueue; // Declarar a fila de requisições

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textEditEmail2 = findViewById(R.id.textEditEmail2);
        textIEditNovaSenha2 = findViewById(R.id.textIEditNovaSenha2);
        button = findViewById(R.id.button);

        // Inicializar a fila de requisições do Volley
        requestQueue = Volley.newRequestQueue(this);

        // Definir padding para bordas do sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        button.setOnClickListener(v -> alterarSenha());
    }

    private void alterarSenha() {
        String email = textEditEmail2.getText().toString().trim();
        String novaSenha = textIEditNovaSenha2.getText().toString().trim();

        if (email.isEmpty() || novaSenha.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "https://doamaisapi.azurewebsites.net/api/Recuperar_Senha";

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("email", email);
            jsonBody.put("senha", novaSenha);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                url,
                jsonBody,
                response -> {
                    Toast.makeText(MainActivity2.this, "Senha alterada com sucesso!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity2.this, MainActivity4.class);
                    startActivity(intent);
                },
                error -> {
                    if (error.networkResponse != null) {
                        Toast.makeText(MainActivity2.this, "O email fornecido não está registrado na base de dados.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity2.this, "Senha alterada com sucesso!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                        startActivity(intent);
                    }
                }
        );

        requestQueue.add(request);
    }
}
