package br.fecap.pi.doamais;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Patterns;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import br.fecap.pi.doamais.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity4 extends AppCompatActivity {
    private static final int REQUEST_GALLERY = 1;
    private static final int REQUEST_CAMERA = 2;
    private static final int REQUEST_STORAGE_PERMISSION = 3;

    private Spinner OngBeneficiada4;
    private ImageView imageView4;
    private TextView textView4;
    private TextInputLayout textInputEmail4, textInputValor4;
    private TextInputEditText textEditEmail4, textIEditValor4;
    private Button btn4;
    private boolean imagemAdicionada = false;
    private String imagemBase64 = ""; // Para armazenar a imagem em Base64

    private static final String URL_ADD_CUPOM = "https://doamaisapi.azurewebsites.net/api/Add_Cupom";
    private static final String URL_ADICIONAR_RECEBE = "https://doamaisapi.azurewebsites.net/api/Recebe/AdicionarRecebe";

    private final int SHIFT = 3; // Deslocamento para a cifra de César

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        OngBeneficiada4 = findViewById(R.id.OngBeneficiada4);
        imageView4 = findViewById(R.id.imageView4);
        textView4 = findViewById(R.id.textView4);
        textInputEmail4 = findViewById(R.id.textInputEmail4);
        textEditEmail4 = findViewById(R.id.textEditEmail4);
        textInputValor4 = findViewById(R.id.textInputValor4);
        textIEditValor4 = findViewById(R.id.textIEditValor4);
        btn4 = findViewById(R.id.buttonEnviar4);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Ong_Beneficiada, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        OngBeneficiada4.setAdapter(adapter);

        imageView4.setOnClickListener(v -> showImageOptionDialog());


        btn4.setOnClickListener(v -> {
            String email = textEditEmail4.getText().toString();
            String valorCupom = textIEditValor4.getText().toString();
            String ongSelecionada = OngBeneficiada4.getSelectedItem().toString();

            if (validaCampos(email, valorCupom, ongSelecionada, imagemAdicionada)) {
                enviarCupomParaApi(email, valorCupom, ongSelecionada);
                enviarRecebeParaApi(email, ongSelecionada);
                limparCampos();
            }
        });
    }

    private void showImageOptionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecione uma opção")
                .setItems(new CharSequence[]{"Galeria", "Câmera"}, (dialog, which) -> {
                    if (which == 0) {
                        openGallery();
                    } else {
                        openCamera();
                    }
                })
                .show();
    }

    private void enviarCupomParaApi(String email, String valorCupom, String ongSelecionada) {
        RequestQueue queue = Volley.newRequestQueue(this);

        // Criptografando email e valor do cupom
        String encryptedEmail = caesarCipher(email, SHIFT);
        String encryptedValorCupom = caesarCipher(valorCupom, SHIFT);

        JSONObject cupomData = new JSONObject();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault());
        String dataEnvio = sdf.format(new Date(System.currentTimeMillis()));
        try {
            cupomData.put("id_cupom", 0);
            cupomData.put("data_envio", dataEnvio);
            cupomData.put("ong_beneficiada", ongSelecionada);
            cupomData.put("valor_cupom", encryptedValorCupom); // Criptografado
            cupomData.put("email", encryptedEmail); // Criptografado

        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest addCupomRequest = new JsonObjectRequest(Request.Method.POST, URL_ADD_CUPOM, cupomData,
                response -> Toast.makeText(MainActivity4.this, "Cupom adicionado com sucesso!", Toast.LENGTH_SHORT).show(),
                error -> {
                    if (error.networkResponse != null) {
                        Toast.makeText(MainActivity4.this, "O email fornecido não está registrado na base de dados.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity4.this, "Cupom adicionado com sucesso!", Toast.LENGTH_LONG).show();
                    }
                }
        );

        queue.add(addCupomRequest);
    }

    private void enviarRecebeParaApi(String email, String ongSelecionada) {
        RequestQueue queue = Volley.newRequestQueue(this);

        // Criptografando email
        String encryptedEmail = caesarCipher(email, SHIFT);

        JSONObject recebeData = new JSONObject();
        try {
            recebeData.put("email", encryptedEmail); // Criptografado
            recebeData.put("nome_ong", ongSelecionada);
            recebeData.put("documento", imagemBase64);
            recebeData.put("imagem_cupom", imagemBase64);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest adicionarRecebeRequest = new JsonObjectRequest(
                Request.Method.POST,
                URL_ADICIONAR_RECEBE,
                recebeData,
                response -> { /* Sucesso: sem ação de feedback visual */ },
                error -> { /* Erro: sem ação de feedback visual */ }
        );

        queue.add(adicionarRecebeRequest);
    }

    private void openGallery() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_MEDIA_IMAGES}, REQUEST_STORAGE_PERMISSION);
        } else {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(galleryIntent, REQUEST_GALLERY);
        }
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
        } else {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, REQUEST_CAMERA);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_GALLERY && data != null) {
                Uri selectedImageUri = data.getData();
                if (selectedImageUri != null) {
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                        imageView4.setImageURI(selectedImageUri);
                        textView4.setText("    Cupom Fiscal adicionado");
                        imagemBase64 = convertBitmapToBase64(bitmap); // Converte para Base64
                        imagemAdicionada = true;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } else if (requestCode == REQUEST_CAMERA && data != null) {
                Bitmap photo = (Bitmap) data.getExtras().get("data");
                if (photo != null) {
                    imageView4.setImageBitmap(photo);
                    textView4.setText("    Cupom Fiscal adicionado");
                    imagemBase64 = convertBitmapToBase64(photo); // Converte para Base64
                    imagemAdicionada = true;
                }
            }
        }
    }

    private String convertBitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
        byte[] imageBytes = outputStream.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    private boolean validaCampos(String email, String valorCupom, String ongSelecionada, boolean imagemAdicionada) {
        boolean valido = true;

        if (TextUtils.isEmpty(ongSelecionada) || ongSelecionada.equals("Selecione a Ong Beneficiada")) {
            Toast.makeText(this, "Selecione a Ong Beneficiada", Toast.LENGTH_SHORT).show();
            valido = false;
        }

        if (!imagemAdicionada) {
            Toast.makeText(this, "Adicione um cupom fiscal", Toast.LENGTH_SHORT).show();
            valido = false;
        }

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            textInputEmail4.setError("Insira um email válido");
            valido = false;
        } else {
            textInputEmail4.setError(null);
        }

        if (TextUtils.isEmpty(valorCupom)) {
            textInputValor4.setError("Insira o valor do cupom");
            valido = false;
        } else {
            textInputValor4.setError(null);
        }

        return valido;
    }

    // Método de criptografia usando a cifra de César
    private String caesarCipher(String input, int shift) {
        StringBuilder result = new StringBuilder();
        for (char c : input.toCharArray()) {
            if (Character.isLetter(c)) {
                char shiftedChar = (char) (c + shift);
                if (Character.isLowerCase(c) && shiftedChar > 'z' || Character.isUpperCase(c) && shiftedChar > 'Z') {
                    shiftedChar -= 26;
                }
                result.append(shiftedChar);
            } else if (Character.isDigit(c)) {
                char shiftedChar = (char) (c + shift);
                if (shiftedChar > '9') {
                    shiftedChar -= 10; // Ajuste para manter entre 0-9
                }
                result.append(shiftedChar);
            } else {
                result.append(c); // Mantém caracteres especiais sem modificação
            }
        }
        return result.toString();
    }
    private void limparCampos() {

        textIEditValor4.setText("");
        textView4.setText("    Envie a imagem do Cupom Fiscal");  // Limpa o texto da imagem
        imagemBase64 = "";  // Limpa a string da imagem em Base64
        imagemAdicionada = false;  // Reseta a flag
    }
}

