package br.fecap.pi.doamais;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import br.fecap.pi.doamais.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity3 extends AppCompatActivity {

    private Spinner textInputTipessoa;
    private TextInputLayout textInputNome;
    private TextInputLayout textInputTelefone;
    private TextInputLayout textInputEmail;
    private TextInputLayout textInputSenha;
    private TextInputEditText textIEditNome;
    private TextInputEditText textIEditTelefone;
    private TextInputEditText textIEditEmail;
    private TextInputEditText textIEditSenha;
    private Button btnFinalizar;

    private final int SHIFT = 3; // Deslocamento para a cifra de César

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        textInputTipessoa = findViewById(R.id.textInputTipessoa3);
        textInputNome = findViewById(R.id.textInputNome3);
        textInputTelefone = findViewById(R.id.textInputTelefone3);
        textInputEmail = findViewById(R.id.textInputEmail3);
        textInputSenha = findViewById(R.id.textInputSenha3);
        textIEditNome = findViewById(R.id.textIEditNome3);
        textIEditTelefone = findViewById(R.id.textIEditTelefone3);
        textIEditEmail = findViewById(R.id.textIEditEmail3);
        textIEditSenha = findViewById(R.id.textIEditSenha3);
        btnFinalizar = findViewById(R.id.btn3);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Tipo_De_Pessoa, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        textInputTipessoa.setAdapter(adapter);

        btnFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                criarConta();
            }
        });
    }

    public void criarConta() {
        String nome = textIEditNome.getText().toString().trim();
        String telefone = textIEditTelefone.getText().toString().trim();
        String email = textIEditEmail.getText().toString().trim();
        String senha = textIEditSenha.getText().toString().trim();
        String tipoPessoa = textInputTipessoa.getSelectedItem() != null ? textInputTipessoa.getSelectedItem().toString() : "";

        if (validaCampos(tipoPessoa, nome, telefone, email, senha)) {
            // Aplicar cifra de César nos valores antes de enviar para a API
            String encryptedNome = caesarCipher(nome, SHIFT);
            String encryptedTelefone = caesarCipher(telefone, SHIFT);
            String encryptedEmail = caesarCipher(email, SHIFT);
            String encryptedSenha = caesarCipher(senha, SHIFT);

            enviarDadosParaApi(encryptedNome, encryptedTelefone, encryptedEmail, encryptedSenha, tipoPessoa);
        }
    }

    private boolean validaCampos(String tipoPessoa, String nome, String telefone, String email, String senha) {
        boolean valido = true;

        if (TextUtils.isEmpty(tipoPessoa) || tipoPessoa.equals("Selecione o Tipo de Pessoa:")) {
            Toast.makeText(this, "Escolha CPF ou CNPJ", Toast.LENGTH_SHORT).show();
            valido = false;
        }

        if (TextUtils.isEmpty(nome)) {
            textInputNome.setError("Insira seu nome completo");
            valido = false;
        } else {
            textInputNome.setError(null);
        }

        if (TextUtils.isEmpty(telefone) || telefone.length() < 9 || telefone.length() > 11 || !TextUtils.isDigitsOnly(telefone)) {
            textInputTelefone.setError("Insira um número de telefone válido (9 ou 11 dígitos)");
            valido = false;
        } else {
            textInputTelefone.setError(null);
        }

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            textInputEmail.setError("Insira um e-mail válido");
            valido = false;
        } else {
            textInputEmail.setError(null);
        }

        if (TextUtils.isEmpty(senha) || senha.length() < 8 || senha.length() > 20 || senha.contains(" ") || !senha.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]+$")) {
            textInputSenha.setError("A senha deve ter entre 8 e 20 caracteres, letras e números, sem espaços ou emojis");
            valido = false;
        } else {
            textInputSenha.setError(null);
        }

        return valido;
    }

    private void enviarDadosParaApi(String nome, String telefone, String email, String senha, String tipoPessoa) {
        String url = "https://doamaisapi.azurewebsites.net/api/Criacao_Usuario";
        int tipoPessoaInt = tipoPessoa.equals("CPF") ? 0 : 1;

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("nome", nome);
            jsonBody.put("senha", senha);
            jsonBody.put("email", email);
            jsonBody.put("telefone", telefone);
            jsonBody.put("tipo_pessoa", tipoPessoaInt);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                url,
                jsonBody,
                response -> {
                    Toast.makeText(MainActivity3.this, "Usuário criado com sucesso!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
                    startActivity(intent);
                },
                error -> {
                    if (error.networkResponse != null) {
                        Toast.makeText(MainActivity3.this, "E-mail já cadastrado na nossa base de dados", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity3.this, "Usuário criado com sucesso!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity3.this, MainActivity.class);
                        startActivity(intent);
                    }
                }
        );

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

    private String caesarCipher(String text, int shift) {
        StringBuilder result = new StringBuilder();

        for (char character : text.toCharArray()) {
            if (Character.isLetter(character)) {
                char base = Character.isLowerCase(character) ? 'a' : 'A';
                character = (char) ((character - base + shift) % 26 + base);
            } else if (Character.isDigit(character)) {
                character = (char) ((character - '0' + shift) % 10 + '0');
            }
            result.append(character);
        }
        return result.toString();
    }
}
